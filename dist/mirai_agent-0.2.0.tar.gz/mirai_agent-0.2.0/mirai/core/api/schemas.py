"""Pydantic request/response models for the Mirai HTTP API."""

from __future__ import annotations

from pydantic import BaseModel, Field


class ChatRequest(BaseModel):
    prompt: str
    session_id: str = "default"
    think: bool = False


class FileUploadRequest(BaseModel):
    """JSON body for ``POST /uploads`` (base64 file)."""

    session_id: str = "default"
    filename: str
    content_base64: str


class SystemPromptUpdateRequest(BaseModel):
    system_prompt: str


class MemoryCreateRequest(BaseModel):
    session_id: str
    role: str
    content: str
    thought: str | None = None


class MemoryUpdateRequest(BaseModel):
    content: str
    role: str | None = None


class SessionCreateRequest(BaseModel):
    title: str | None = None


class SessionUpdateRequest(BaseModel):
    title: str | None = None
    is_pinned: bool | None = None
    status: str | None = None


class ToolToggleRequest(BaseModel):
    tool_name: str
    disabled: bool


class ToolConfirmationToggleRequest(BaseModel):
    tool_name: str
    require_confirmation: bool


class ToolConfirmationResponse(BaseModel):
    call_id: str
    decision: str  # "allow" | "deny" | "always_allow"


class ModelConfigUpdateRequest(BaseModel):
    chat_provider: str | None = None
    chat_model: str | None = None
    embedding_provider: str | None = None
    embedding_model: str | None = None
    memory_max_recent_messages: int | None = Field(default=None, ge=1, le=500)
    memory_max_related_messages: int | None = Field(default=None, ge=0, le=100)
    chat_append_current_time: bool | None = None
    chat_append_tool_use_instruction: bool | None = None
    # Stored in ~/.mirai/config.json; omit or leave empty to keep existing value.
    openai_api_key: str | None = None
    gemini_api_key: str | None = None
    claude_api_key: str | None = None
    openai_base_url: str | None = None


class SessionPromptRequest(BaseModel):
    system_prompt: str


class UIPreferencesRequest(BaseModel):
    dark_mode: bool = True
