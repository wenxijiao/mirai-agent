"""Plugin port definitions.

Each ``Protocol`` describes one extension point that the OSS core calls into
during normal request handling. The OSS ships trivial single-user defaults in
:mod:`mirai.core.plugins.single_user`; commercial / enterprise builds register
richer implementations via :func:`mirai.core.plugins.register_plugin`.

The OSS core MUST only depend on these abstractions — never import anything
from a commercial package directly.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any, Protocol, runtime_checkable

from mirai.core.plugins.identity import Identity

if TYPE_CHECKING:
    from fastapi import FastAPI
    from mirai.core.chatbot import MiraiBot
    from mirai.core.memories.memory import Memory


@runtime_checkable
class IdentityProvider(Protocol):
    """Resolve the request-scoped :class:`Identity`."""

    def current(self) -> Identity:
        """Return the identity bound to the current async context."""

    def from_request(self, request: Any) -> Identity | None:
        """Best-effort identity from an incoming HTTP/WS request (default: ``None``)."""


@runtime_checkable
class QuotaPolicy(Protocol):
    """Daily quota / token usage accounting (no-op in OSS)."""

    def check_chat_allowed(self, identity: Identity) -> tuple[bool, str]: ...
    def check_token_quota(self, identity: Identity) -> tuple[bool, str]: ...
    def record_chat_turn(self, identity: Identity) -> int: ...
    def record_chat_tokens(
        self,
        identity: Identity,
        prompt_tokens: int,
        completion_tokens: int,
        *,
        model: str = "unknown",
        kind: str = "chat",
    ) -> None: ...
    def record_embed_tokens(
        self,
        identity: Identity,
        estimated_tokens: int,
        *,
        model: str = "unknown",
    ) -> None: ...
    def chat_quota_snapshot(self, identity: Identity) -> dict: ...


@runtime_checkable
class BillingHook(Protocol):
    """Rough USD estimation hook (returns 0.0 in OSS)."""

    def estimate_usd_for_usage(
        self,
        model: str,
        prompt_tokens: int,
        completion_tokens: int,
    ) -> float: ...


@runtime_checkable
class SessionScope(Protocol):
    """Map raw client session ids to storage session ids (per-user prefix in MT)."""

    def qualify_session_id(self, identity: Identity, client_session_id: str | None) -> str: ...
    def qualify_session_http(self, identity: Identity, client_session_id: str | None) -> str: ...
    def owner_user_from_session_id(self, session_id: str) -> str: ...
    def session_id_prefix_for_identity(self, identity: Identity) -> str | None: ...
    def ensure_session_owned_by_identity(self, identity: Identity, sid: str) -> None: ...
    def ensure_message_owned_by_identity(self, identity: Identity, message: dict) -> None: ...


@runtime_checkable
class BotPool(Protocol):
    """Per-user :class:`MiraiBot` resolution (returns the shared singleton in OSS)."""

    async def get_bot_for_identity(self, identity: Identity) -> "MiraiBot": ...
    async def get_bot_for_session_owner(self, owner_user_id: str) -> "MiraiBot": ...
    def invalidate(self, user_id: str) -> None: ...
    def start_idle_sweep(self) -> None: ...


@runtime_checkable
class MemoryFactory(Protocol):
    """LanceDB :class:`Memory` resolution (returns the shared store in OSS)."""

    def get_for_identity(self, identity: Identity) -> "Memory": ...
    def get_for_session_owner(self, owner_user_id: str) -> "Memory": ...
    def assert_quota_for_session(self, session_id: str) -> None: ...
    def invalidate_size_cache(self, user_id: str) -> None: ...


@runtime_checkable
class EdgeScope(Protocol):
    """Edge connection key / tool prefix scoping (per-user in MT, plain in OSS)."""

    def connection_key(self, owner_user_id: str | None, edge_name: str) -> str: ...
    def tool_register_prefix(self, owner_user_id: str | None, edge_name: str) -> str: ...
    def filter_edge_tool_schemas(
        self,
        identity: Identity,
        registry: dict[str, dict],
        disabled: set[str],
    ) -> list: ...


@runtime_checkable
class AuditSink(Protocol):
    """Audit logging hook (logs only in OSS, also persists in enterprise)."""

    def event(self, event: str, user_id: str | None = None, **fields: object) -> None: ...


@runtime_checkable
class RouteExtender(Protocol):
    """Mount additional FastAPI routes (admin, auth, relay)."""

    def mount(self, app: "FastAPI") -> None: ...


@runtime_checkable
class MiddlewareExtender(Protocol):
    """Return additional ASGI middleware classes to wrap the FastAPI app."""

    def middlewares(self) -> list: ...


@runtime_checkable
class AdminCli(Protocol):
    """Inject extra CLI subcommands into ``mirai-enterprise`` (no-op for ``mirai``)."""

    def add_arguments(self, parser: Any) -> None: ...
    def handle(self, args: Any) -> bool:
        """Handle parsed ``args``. Return True if a command was dispatched."""
