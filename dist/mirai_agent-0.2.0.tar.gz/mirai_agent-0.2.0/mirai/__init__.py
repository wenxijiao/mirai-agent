"""Public package marker for Mirai.

Quick-start API::

    import mirai

    mirai.register(my_func, "What this function does")
    mirai.run()

This creates a default :class:`MiraiAgent` behind the scenes.  For full
control (custom connection code, edge name, multiple agents) use
:class:`mirai.sdk.MiraiAgent` directly.
"""

from __future__ import annotations

__all__ = ["__version__", "MiraiAgent", "register", "run", "stop"]

__version__ = "0.2.0"

from mirai.sdk import MiraiAgent as MiraiAgent

_default_agent: MiraiAgent | None = None


def _get_default_agent() -> MiraiAgent:
    global _default_agent
    if _default_agent is None:
        _default_agent = MiraiAgent()
    return _default_agent


def register(
    func,
    description: str,
    *,
    name: str | None = None,
    params: dict[str, str] | None = None,
    returns: str | None = None,
    timeout: int | None = None,
    require_confirmation: bool = False,
) -> None:
    """Register a tool on the default agent.

    Equivalent to ``MiraiAgent().register(...)`` but uses a shared
    module-level instance so you can write::

        import mirai
        mirai.register(func, "description")
        mirai.run()
    """
    _get_default_agent().register(
        func,
        description,
        name=name,
        params=params,
        returns=returns,
        timeout=timeout,
        require_confirmation=require_confirmation,
    )


def run(
    *,
    connection_code: str | None = None,
    edge_name: str | None = None,
) -> None:
    """Start the default agent in the background.

    Optional *connection_code* and *edge_name* are applied to the
    default agent before starting.  If the agent is already running
    this is a no-op.
    """
    agent = _get_default_agent()
    if connection_code is not None:
        agent._connection_code = connection_code
    if edge_name is not None:
        agent._edge_name = edge_name
    agent.run_in_background()


def stop() -> None:
    """Stop the default agent if it is running."""
    global _default_agent
    if _default_agent is not None:
        _default_agent.stop()
        _default_agent = None
