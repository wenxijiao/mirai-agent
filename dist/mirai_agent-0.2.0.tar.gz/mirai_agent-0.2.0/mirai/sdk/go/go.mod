module mirai_sdk

go 1.21

require github.com/gorilla/websocket v1.5.3
